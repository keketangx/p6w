shiboken_library_soversion = str(6.8)

version = "6.8.2"
version_info = (6, 8, 2, "", "")

__build_date__ = '2025-01-31T16:05:18+00:00'
__build_commit_date__ = '2025-01-27T08:37:37+00:00'
__build_commit_hash__ = 'e6767bdcd184ca9fb0dcbe655d0cde3d9ac519c5'
__build_commit_hash_described__ = 'v6.8.2'

__setup_py_package_version__ = '6.8.2'

